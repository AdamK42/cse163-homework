import pandas


def main():
    print('Setup correct!');


if __name__ == '__main__':
    main()
